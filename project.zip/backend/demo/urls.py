from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import TodoViewSet, index, home, about, contact

# Create a router and register our viewsets with it
router = DefaultRouter()
router.register(r'todos', TodoViewSet)

urlpatterns = [
    # API endpoints
    path('api/', include(router.urls)),
    
    # Basic endpoints
    path('', index, name='index'),
    path('home/', home, name='home'),
    path('about/', about, name='about'),
    path('contact/', contact, name='contact'),
]