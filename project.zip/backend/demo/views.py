from django.shortcuts import render
from django.http import JsonResponse
from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from .models import Todo
from .serializers import TodoSerializer

class TodoViewSet(viewsets.ModelViewSet):
    queryset = Todo.objects.all()
    serializer_class = TodoSerializer
    
    @action(detail=False, methods=['get'])
    def completed(self, request):
        """Get all completed todos"""
        completed_todos = Todo.objects.filter(completed=True)
        serializer = self.get_serializer(completed_todos, many=True)
        return Response(serializer.data)
    
    @action(detail=False, methods=['get'])
    def pending(self, request):
        """Get all pending todos"""
        pending_todos = Todo.objects.filter(completed=False)
        serializer = self.get_serializer(pending_todos, many=True)
        return Response(serializer.data)
    
    @action(detail=True, methods=['patch'])
    def toggle_complete(self, request, pk=None):
        """Toggle completion status of a todo"""
        todo = self.get_object()
        todo.completed = not todo.completed
        todo.save()
        serializer = self.get_serializer(todo)
        return Response(serializer.data)
    
    @action(detail=False, methods=['delete'])
    def clear_completed(self, request):
        """Delete all completed todos"""
        deleted_count = Todo.objects.filter(completed=True).delete()[0]
        return Response({'message': f'Deleted {deleted_count} completed todos'})

# Legacy views for basic endpoints
def index(request):
    return JsonResponse({"message": "Todo API is running!"})

def home(request):
    return JsonResponse({"message": "Welcome to the Todo API!"})

def about(request):
    return JsonResponse({"message": "This is a Todo List API built with Django REST Framework"})

def contact(request):
    return JsonResponse({"message": "Contact us for support!"})

# Error handlers
def not_found(request, exception):
    return JsonResponse({"error": "Page not found"}, status=404)

def server_error(request):
    return JsonResponse({"error": "Internal server error"}, status=500)