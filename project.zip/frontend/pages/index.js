export default function Home() {
  return <h1>🚀 Welcome to your Next.js frontend!</h1>;
}
