import React, { useState, useEffect } from 'react';
import './App.css';
import TodoList from './components/TodoList';
import TodoForm from './components/TodoForm';
import TodoFilter from './components/TodoFilter';

const API_BASE_URL = 'http://localhost:8000/api';

function App() {
  const [todos, setTodos] = useState([]);
  const [filter, setFilter] = useState('all'); // all, pending, completed
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Fetch todos from API
  const fetchTodos = async () => {
    try {
      setLoading(true);
      const response = await fetch(`${API_BASE_URL}/todos/`);
      if (!response.ok) {
        throw new Error('Failed to fetch todos');
      }
      const data = await response.json();
      setTodos(data);
      setError(null);
    } catch (err) {
      setError(err.message);
      console.error('Error fetching todos:', err);
    } finally {
      setLoading(false);
    }
  };

  // Add new todo
  const addTodo = async (todoData) => {
    try {
      const response = await fetch(`${API_BASE_URL}/todos/`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(todoData),
      });
      
      if (!response.ok) {
        throw new Error('Failed to add todo');
      }
      
      const newTodo = await response.json();
      setTodos(prevTodos => [newTodo, ...prevTodos]);
      return newTodo;
    } catch (err) {
      setError(err.message);
      console.error('Error adding todo:', err);
      throw err;
    }
  };

  // Update todo
  const updateTodo = async (id, updates) => {
    try {
      const response = await fetch(`${API_BASE_URL}/todos/${id}/`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(updates),
      });
      
      if (!response.ok) {
        throw new Error('Failed to update todo');
      }
      
      const updatedTodo = await response.json();
      setTodos(prevTodos => 
        prevTodos.map(todo => 
          todo.id === id ? updatedTodo : todo
        )
      );
      return updatedTodo;
    } catch (err) {
      setError(err.message);
      console.error('Error updating todo:', err);
      throw err;
    }
  };

  // Delete todo
  const deleteTodo = async (id) => {
    try {
      const response = await fetch(`${API_BASE_URL}/todos/${id}/`, {
        method: 'DELETE',
      });
      
      if (!response.ok) {
        throw new Error('Failed to delete todo');
      }
      
      setTodos(prevTodos => prevTodos.filter(todo => todo.id !== id));
    } catch (err) {
      setError(err.message);
      console.error('Error deleting todo:', err);
      throw err;
    }
  };

  // Toggle todo completion
  const toggleTodo = async (id) => {
    try {
      const response = await fetch(`${API_BASE_URL}/todos/${id}/toggle_complete/`, {
        method: 'PATCH',
      });
      
      if (!response.ok) {
        throw new Error('Failed to toggle todo');
      }
      
      const updatedTodo = await response.json();
      setTodos(prevTodos => 
        prevTodos.map(todo => 
          todo.id === id ? updatedTodo : todo
        )
      );
    } catch (err) {
      setError(err.message);
      console.error('Error toggling todo:', err);
    }
  };

  // Clear completed todos
  const clearCompleted = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/todos/clear_completed/`, {
        method: 'DELETE',
      });
      
      if (!response.ok) {
        throw new Error('Failed to clear completed todos');
      }
      
      setTodos(prevTodos => prevTodos.filter(todo => !todo.completed));
    } catch (err) {
      setError(err.message);
      console.error('Error clearing completed todos:', err);
    }
  };

  // Filter todos based on current filter
  const filteredTodos = todos.filter(todo => {
    switch (filter) {
      case 'pending':
        return !todo.completed;
      case 'completed':
        return todo.completed;
      default:
        return true;
    }
  });

  // Load todos on component mount
  useEffect(() => {
    fetchTodos();
  }, []);

  const stats = {
    total: todos.length,
    pending: todos.filter(todo => !todo.completed).length,
    completed: todos.filter(todo => todo.completed).length,
  };

  return (
    <div className="App">
      <div className="container">
        <header className="app-header">
          <h1>📝 Todo List</h1>
          <div className="stats">
            <span className="stat">Total: {stats.total}</span>
            <span className="stat">Pending: {stats.pending}</span>
            <span className="stat">Completed: {stats.completed}</span>
          </div>
        </header>

        {error && (
          <div className="error-message">
            <p>❌ {error}</p>
            <button onClick={fetchTodos} className="retry-btn">
              Retry
            </button>
          </div>
        )}

        <TodoForm onAddTodo={addTodo} />
        
        <TodoFilter 
          currentFilter={filter} 
          onFilterChange={setFilter}
          onClearCompleted={clearCompleted}
          hasCompleted={stats.completed > 0}
        />

        {loading ? (
          <div className="loading">Loading todos...</div>
        ) : (
          <TodoList
            todos={filteredTodos}
            onToggleTodo={toggleTodo}
            onUpdateTodo={updateTodo}
            onDeleteTodo={deleteTodo}
          />
        )}

        {!loading && filteredTodos.length === 0 && (
          <div className="empty-state">
            <p>
              {filter === 'all' 
                ? "No todos yet. Add one above!" 
                : `No ${filter} todos.`
              }
            </p>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;