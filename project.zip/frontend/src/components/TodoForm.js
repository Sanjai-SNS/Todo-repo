import React, { useState } from 'react';

const TodoForm = ({ onAddTodo }) => {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    priority: 'medium',
    due_date: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!formData.title.trim()) {
      alert('Please enter a title for your todo');
      return;
    }

    setIsSubmitting(true);
    
    try {
      const todoData = {
        ...formData,
        title: formData.title.trim(),
        description: formData.description.trim(),
        due_date: formData.due_date || null
      };
      
      await onAddTodo(todoData);
      
      // Reset form
      setFormData({
        title: '',
        description: '',
        priority: 'medium',
        due_date: ''
      });
    } catch (error) {
      console.error('Failed to add todo:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="todo-form">
      <div className="form-row">
        <input
          type="text"
          name="title"
          value={formData.title}
          onChange={handleChange}
          placeholder="What needs to be done?"
          className="todo-input"
          disabled={isSubmitting}
          required
        />
        <select
          name="priority"
          value={formData.priority}
          onChange={handleChange}
          className="priority-select"
          disabled={isSubmitting}
        >
          <option value="low">Low Priority</option>
          <option value="medium">Medium Priority</option>
          <option value="high">High Priority</option>
        </select>
      </div>
      
      <div className="form-row">
        <textarea
          name="description"
          value={formData.description}
          onChange={handleChange}
          placeholder="Description (optional)"
          className="todo-description"
          rows="2"
          disabled={isSubmitting}
        />
        <input
          type="datetime-local"
          name="due_date"
          value={formData.due_date}
          onChange={handleChange}
          className="due-date-input"
          disabled={isSubmitting}
        />
      </div>
      
      <button 
        type="submit" 
        className="add-btn"
        disabled={isSubmitting || !formData.title.trim()}
      >
        {isSubmitting ? 'Adding...' : '+ Add Todo'}
      </button>
    </form>
  );
};

export default TodoForm;