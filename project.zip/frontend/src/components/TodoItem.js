import React, { useState } from 'react';

const TodoItem = ({ todo, onToggle, onUpdate, onDelete }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editData, setEditData] = useState({
    title: todo.title,
    description: todo.description || '',
    priority: todo.priority,
    due_date: todo.due_date ? todo.due_date.slice(0, 16) : ''
  });

  const handleEdit = () => {
    setIsEditing(true);
  };

  const handleSave = async () => {
    try {
      const updates = {
        ...editData,
        title: editData.title.trim(),
        description: editData.description.trim(),
        due_date: editData.due_date || null
      };
      
      await onUpdate(todo.id, updates);
      setIsEditing(false);
    } catch (error) {
      console.error('Failed to update todo:', error);
    }
  };

  const handleCancel = () => {
    setEditData({
      title: todo.title,
      description: todo.description || '',
      priority: todo.priority,
      due_date: todo.due_date ? todo.due_date.slice(0, 16) : ''
    });
    setIsEditing(false);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setEditData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const formatDate = (dateString) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toLocaleString();
  };

  const isOverdue = () => {
    if (!todo.due_date || todo.completed) return false;
    return new Date(todo.due_date) < new Date();
  };

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'high': return '#ff4757';
      case 'medium': return '#ffa502';
      case 'low': return '#2ed573';
      default: return '#747d8c';
    }
  };

  if (isEditing) {
    return (
      <div className="todo-item editing">
        <div className="edit-form">
          <input
            type="text"
            name="title"
            value={editData.title}
            onChange={handleChange}
            className="edit-title"
            required
          />
          <textarea
            name="description"
            value={editData.description}
            onChange={handleChange}
            className="edit-description"
            placeholder="Description"
            rows="2"
          />
          <div className="edit-controls">
            <select
              name="priority"
              value={editData.priority}
              onChange={handleChange}
              className="edit-priority"
            >
              <option value="low">Low</option>
              <option value="medium">Medium</option>
              <option value="high">High</option>
            </select>
            <input
              type="datetime-local"
              name="due_date"
              value={editData.due_date}
              onChange={handleChange}
              className="edit-due-date"
            />
          </div>
          <div className="edit-actions">
            <button onClick={handleSave} className="save-btn">
              ✓ Save
            </button>
            <button onClick={handleCancel} className="cancel-btn">
              ✕ Cancel
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`todo-item ${todo.completed ? 'completed' : ''} ${isOverdue() ? 'overdue' : ''}`}>
      <div className="todo-content">
        <div className="todo-main">
          <input
            type="checkbox"
            checked={todo.completed}
            onChange={onToggle}
            className="todo-checkbox"
          />
          <div className="todo-text">
            <h3 className="todo-title">{todo.title}</h3>
            {todo.description && (
              <p className="todo-description">{todo.description}</p>
            )}
          </div>
        </div>
        
        <div className="todo-meta">
          <span 
            className="priority-badge"
            style={{ backgroundColor: getPriorityColor(todo.priority) }}
          >
            {todo.priority}
          </span>
          {todo.due_date && (
            <span className={`due-date ${isOverdue() ? 'overdue' : ''}`}>
              📅 {formatDate(todo.due_date)}
            </span>
          )}
          <span className="created-date">
            Created: {formatDate(todo.created_at)}
          </span>
        </div>
      </div>
      
      <div className="todo-actions">
        <button onClick={handleEdit} className="edit-btn" title="Edit">
          ✏️
        </button>
        <button onClick={onDelete} className="delete-btn" title="Delete">
          🗑️
        </button>
      </div>
    </div>
  );
};

export default TodoItem;