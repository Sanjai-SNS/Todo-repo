import React from 'react';

const TodoFilter = ({ currentFilter, onFilterChange, onClearCompleted, hasCompleted }) => {
  const filters = [
    { key: 'all', label: 'All', icon: '📋' },
    { key: 'pending', label: 'Pending', icon: '⏳' },
    { key: 'completed', label: 'Completed', icon: '✅' }
  ];

  return (
    <div className="todo-filter">
      <div className="filter-buttons">
        {filters.map(filter => (
          <button
            key={filter.key}
            onClick={() => onFilterChange(filter.key)}
            className={`filter-btn ${currentFilter === filter.key ? 'active' : ''}`}
          >
            <span className="filter-icon">{filter.icon}</span>
            {filter.label}
          </button>
        ))}
      </div>
      
      {hasCompleted && (
        <button 
          onClick={onClearCompleted} 
          className="clear-completed-btn"
          title="Clear all completed todos"
        >
          🧹 Clear Completed
        </button>
      )}
    </div>
  );
};

export default TodoFilter;